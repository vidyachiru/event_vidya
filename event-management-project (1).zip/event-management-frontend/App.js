import React from 'react';
import EventList from './components/EventList';

const App = () => (
  <div>
    <h1>Event Management Dashboard</h1>
    <EventList />
  </div>
);

export default App;
