import axios from 'axios';

export const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const fetchEvents = () => API.get('/events');
export const createEvent = (event) => API.post('/events', event);
export const deleteEvent = (id) => API.delete(`/events/${id}`);
