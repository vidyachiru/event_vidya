import React, { useEffect, useState } from 'react';
import { fetchEvents, deleteEvent } from '../api';

const EventList = () => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetchEvents();
      setEvents(response.data);
    };
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    await deleteEvent(id);
    setEvents(events.filter((event) => event._id !== id));
  };

  return (
    <div>
      <h1>Event List</h1>
      {events.map((event) => (
        <div key={event._id}>
          <h3>{event.name}</h3>
          <p>{event.description}</p>
          <button onClick={() => handleDelete(event._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default EventList;
